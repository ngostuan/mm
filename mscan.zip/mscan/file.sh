#!/bin/bash
if [ -z "$1" ]; then
  echo "No domain provided"
  exit 1
fi

DOMAIN=$1
echo "Running paramspider for $DOMAIN"
paramspider -d "$DOMAIN"
cat results/$DOMAIN.txt | uro > param.txt
cat param.txt | sed 's/FUZZ//g' > output.txt
python3 mscan.py
