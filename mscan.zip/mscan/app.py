from flask import Flask, render_template, request, Response
import subprocess

app = Flask(__name__)

def stream_script_output(domain):
    # Chạy file.sh với domain được truyền vào
    process = subprocess.Popen(
        ['bash', 'file.sh', domain], 
        stdout=subprocess.PIPE, 
        stderr=subprocess.PIPE, 
        text=True
    )
    # Gửi từng dòng output tới client
    for line in iter(process.stdout.readline, ''):
        yield f"data: {line.strip()}\n\n"
    process.stdout.close()
    return_code = process.wait()
    if return_code != 0:
        yield f"data: Script exited with error code {return_code}\n\n"

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        domain = request.form.get('domain')
        return render_template('output.html', domain=domain)
    return render_template('index.html')

@app.route('/stream/<domain>')
def stream(domain):
    # Sử dụng Server-Sent Events để truyền output
    return Response(stream_script_output(domain), mimetype='text/event-stream')

if __name__ == '__main__':
    app.run(debug=True)
